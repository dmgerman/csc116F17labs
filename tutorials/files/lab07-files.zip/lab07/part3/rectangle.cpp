/*
 * rectangle.cpp
 * CSC 116 Fall 2017 - Lab 07
 *
 * Implementation of the rectangle class
 */

#include "rectangle.hpp"

Rectangle::Rectangle(Point const & min, Point const & max) {
    // Implement me!
}

Rectangle::Rectangle(double x, double y, double width, double height) {
    // Implement me!
}

double Rectangle::area() const {
    // Implement me!
}

double Rectangle::perimeter() const {
    // Implement me!
}

Point Rectangle::center() const {
    // Implement me!
}

std::string Rectangle::name() const {
    return "Rectangle";
}

double Rectangle::width() const {
    // Implement me!
}

double Rectangle::height() const {
    // Implement me!
}

Point Rectangle::getMin() const {
    // Implement me!
}

Point Rectangle::getMax() const {
    // Implement me!
}
