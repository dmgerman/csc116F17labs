#include "square.hpp"

Square::Square(Point const & min, double width) {
  // Implement me!
}
