/* square.hpp
  
   CSC 116 Fall 2016 - Lab 7
   
*/

#include <string>
#include <cmath>
#include <iostream>
#include <sstream>

#include "circle.hpp"

Circle::Circle(const Circle &sq)
{
    // write your code here
}

Circle::Circle(double _x, double _y, double _radius)
{
    // write your code here
}

Circle::Circle()
{
    // write your code here
}

double Circle::getRadius()  const
{
    // write your code here
}

double Circle::area() 
{
    // write your code here
}

std::string Circle::name() 
{
    return "circle";
}

std::string Circle::properties() 
{
    // write your code here
}
